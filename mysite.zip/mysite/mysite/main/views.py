from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required

def about(request):
    return render(request, 'main/about.html')

def catalog(request):
    items = [
        {'title': 'Товар 1', 'desc': 'Описание первого товара', 'price': '1 200 ₽'},
        {'title': 'Товар 2', 'desc': 'Описание второго товара', 'price': '850 ₽'},
        {'title': 'Товар 3', 'desc': 'Описание третьего товара', 'price': '3 400 ₽'},
        {'title': 'Товар 4', 'desc': 'Описание четвёртого товара', 'price': '600 ₽'},
        {'title': 'Товар 5', 'desc': 'Описание пятого товара', 'price': '2 100 ₽'},
        {'title': 'Товар 6', 'desc': 'Описание шестого товара', 'price': '980 ₽'},
    ]
    return render(request, 'main/catalog.html', {'items': items})

@login_required
def profile(request):
    return render(request, 'main/profile.html')

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('profile')
    else:
        form = UserCreationForm()
    return render(request, 'main/register.html', {'form': form})
